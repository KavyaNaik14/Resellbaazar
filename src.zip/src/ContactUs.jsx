import React, { useState } from "react";
import axios from "axios";

function ContactUs() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    message: ""
  });

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  function handleSubmit() {
    axios.post("http://localhost:9000/contact", form)
      .then(() => {
        alert("Message sent successfully!");
        setForm({ name: "", email: "", message: "" });
      })
      .catch(() => alert("Error sending message"));
  }

  return (
    <div className="contactPage">
      <h1>Contact Us</h1>

      <div className="contactContainer">
        <div className="contactInfo">
          <p>📍 Bangalore, India</p>
          <p>📞 +91 9876543210</p>
          <p>📧 support@resellbazaar.com</p>
        </div>

        <div className="contactForm">
          <input
            name="name"
            value={form.name}
            onChange={handleChange}
            placeholder="Your Name"
          />

          <input
            name="email"
            value={form.email}
            onChange={handleChange}
            placeholder="Your Email"
          />

          <textarea
            name="message"
            value={form.message}
            onChange={handleChange}
            placeholder="Your Message"
          />

          <button onClick={handleSubmit}>
            Send Message
          </button>
        </div>
      </div>
    </div>
  );
}

export default ContactUs;